// David Winer
// 2017 - 02 - 25

//Instructions for DIRT assignment
// "unzip DIRT.zip"
// "chmod +x dirt.py"
// "python3 dirt.py <corpus.txt> <text.txt> <min_freq>"